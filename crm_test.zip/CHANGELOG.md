## [1.0.1] 2019-11-12

### HotFix
- small fix on responsive for Profile Page
- added pre-cache for images for a faster experience

## [1.0.0] 2019-11-11

### Initial Release
