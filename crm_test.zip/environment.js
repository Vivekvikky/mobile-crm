export const environment={
    BASE_URL:'http://192.168.0.108:3004'
}
export default environment;